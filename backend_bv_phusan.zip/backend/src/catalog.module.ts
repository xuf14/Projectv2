import { Injectable, Controller, Get, Post, Body, Param, Query, UseGuards } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { KhoaPhong, BacSi, KhungGio, TinTuc, VaiTro } from './entities';
import { JwtAuthGuard, RolesGuard, Roles } from './auth';

@Injectable()
export class CatalogService {
  constructor(
    @InjectRepository(KhoaPhong) private khoa: Repository<KhoaPhong>,
    @InjectRepository(BacSi) private bacSi: Repository<BacSi>,
    @InjectRepository(KhungGio) private slot: Repository<KhungGio>,
    @InjectRepository(TinTuc) private tin: Repository<TinTuc>,
  ) {}

  getKhoa() { return this.khoa.find({ relations: ['bac_si'] }); }

  getBacSi(khoaId?: number) {
    const where = khoaId ? { khoa: { id: khoaId } } : {};
    return this.bacSi.find({ where });
  }

  async getSlots(bacSiId: number, ngay: string) {
    const all = await this.slot.find({ where: { bac_si: { id: bacSiId }, ngay } });
    return all
      .filter((s) => s.da_dat < s.so_luong)
      .map((s) => ({ id: s.id, gio_bat_dau: s.gio_bat_dau, gio_ket_thuc: s.gio_ket_thuc, con_lai: s.so_luong - s.da_dat }));
  }

  getTinTuc() { return this.tin.find({ order: { ngay_dang: 'DESC' } }); }

  // --- Admin: thêm khoa / bác sĩ ---
  addKhoa(dto: any) { return this.khoa.save(this.khoa.create(dto)); }
  async addBacSi(dto: any) {
    const khoa = await this.khoa.findOneBy({ id: dto.khoa_id });
    return this.bacSi.save(this.bacSi.create({ ...dto, khoa }));
  }
}

@Controller('api')
export class CatalogController {
  constructor(private svc: CatalogService) {}

  @Get('departments') khoa() { return this.svc.getKhoa(); }
  @Get('doctors') bacSi(@Query('khoa') khoa?: string) { return this.svc.getBacSi(khoa ? +khoa : undefined); }
  @Get('slots') slots(@Query('bacSi') bacSi: string, @Query('ngay') ngay: string) { return this.svc.getSlots(+bacSi, ngay); }
  @Get('news') tin() { return this.svc.getTinTuc(); }

  @UseGuards(JwtAuthGuard, RolesGuard) @Roles(VaiTro.ADMIN)
  @Post('admin/departments') addKhoa(@Body() b: any) { return this.svc.addKhoa(b); }

  @UseGuards(JwtAuthGuard, RolesGuard) @Roles(VaiTro.ADMIN)
  @Post('admin/doctors') addBacSi(@Body() b: any) { return this.svc.addBacSi(b); }
}
