import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';

import {
  NguoiDung, KhoaPhong, BacSi, DichVu, HoSoBenhNhan, KhungGio, LichHen, LuotKham, DonThuoc, TinTuc,
} from './entities';
import { JwtStrategy, RolesGuard, JWT_SECRET } from './auth';
import { AuthService, AuthController } from './auth.module';
import { CatalogService, CatalogController } from './catalog.module';
import { ApptService, ApptController } from './appointment.module';

const ENTITIES = [NguoiDung, KhoaPhong, BacSi, DichVu, HoSoBenhNhan, KhungGio, LichHen, LuotKham, DonThuoc, TinTuc];

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'sqlite',
      database: process.env.DB_PATH || 'bv_phusan.sqlite',
      entities: ENTITIES,
      synchronize: true, // tự tạo bảng — chỉ dùng cho dev
    }),
    TypeOrmModule.forFeature(ENTITIES),
    PassportModule,
    JwtModule.register({ secret: JWT_SECRET, signOptions: { expiresIn: '7d' } }),
  ],
  controllers: [AuthController, CatalogController, ApptController],
  providers: [AuthService, CatalogService, ApptService, JwtStrategy, RolesGuard],
})
export class AppModule {}
