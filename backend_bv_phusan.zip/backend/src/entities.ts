import {
  Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany, OneToOne,
  JoinColumn, CreateDateColumn,
} from 'typeorm';

// ---- Vai trò ----
export enum VaiTro {
  BENH_NHAN = 'benh_nhan',
  LE_TAN = 'le_tan',
  BAC_SI = 'bac_si',
  ADMIN = 'admin',
}

@Entity('nguoi_dung')
export class NguoiDung {
  @PrimaryGeneratedColumn() id: number;
  @Column() ho_ten: string;
  @Column({ unique: true, nullable: true }) sdt: string;
  @Column({ unique: true, nullable: true }) email: string;
  @Column() mat_khau_hash: string;
  @Column({ type: 'simple-enum', enum: VaiTro, default: VaiTro.BENH_NHAN }) vai_tro: VaiTro;
  @Column({ default: true }) trang_thai: boolean;
  @CreateDateColumn() ngay_tao: Date;

  @OneToMany(() => HoSoBenhNhan, (h) => h.nguoi_dung) ho_so: HoSoBenhNhan[];
}

@Entity('khoa_phong')
export class KhoaPhong {
  @PrimaryGeneratedColumn() id: number;
  @Column() ten_khoa: string;
  @Column({ nullable: true }) ma: string;
  @Column({ type: 'text', nullable: true }) mo_ta: string;
  @Column({ nullable: true }) vi_tri: string;

  @OneToMany(() => BacSi, (b) => b.khoa) bac_si: BacSi[];
  @OneToMany(() => DichVu, (d) => d.khoa) dich_vu: DichVu[];
}

@Entity('bac_si')
export class BacSi {
  @PrimaryGeneratedColumn() id: number;
  @Column() ho_ten: string;
  @Column({ nullable: true }) hoc_ham: string;
  @Column({ nullable: true }) chuyen_mon: string;
  @Column({ type: 'int', default: 0 }) so_nam_kn: number;
  @Column({ type: 'float', default: 5 }) danh_gia: number;

  @ManyToOne(() => KhoaPhong, (k) => k.bac_si, { eager: true }) @JoinColumn({ name: 'khoa_id' }) khoa: KhoaPhong;
  @OneToMany(() => KhungGio, (s) => s.bac_si) khung_gio: KhungGio[];
}

@Entity('dich_vu')
export class DichVu {
  @PrimaryGeneratedColumn() id: number;
  @Column() ten_dich_vu: string;
  @Column({ type: 'int', default: 0 }) gia: number;
  @ManyToOne(() => KhoaPhong, (k) => k.dich_vu) @JoinColumn({ name: 'khoa_id' }) khoa: KhoaPhong;
}

@Entity('ho_so_benh_nhan')
export class HoSoBenhNhan {
  @PrimaryGeneratedColumn() id: number;
  @Column({ unique: true }) ma_benh_nhan: string;
  @Column() ho_ten: string;
  @Column({ type: 'date', nullable: true }) ngay_sinh: string;
  @Column({ nullable: true }) gioi_tinh: string;
  @Column({ nullable: true }) dia_chi: string;
  @Column({ nullable: true }) sdt: string;
  @Column({ nullable: true }) so_bhyt: string;

  @ManyToOne(() => NguoiDung, (n) => n.ho_so) @JoinColumn({ name: 'nguoi_dung_id' }) nguoi_dung: NguoiDung;
  @OneToMany(() => LichHen, (l) => l.ho_so) lich_hen: LichHen[];
}

@Entity('khung_gio')
export class KhungGio {
  @PrimaryGeneratedColumn() id: number;
  @Column({ type: 'date' }) ngay: string;
  @Column() gio_bat_dau: string;
  @Column() gio_ket_thuc: string;
  @Column({ type: 'int', default: 5 }) so_luong: number;
  @Column({ type: 'int', default: 0 }) da_dat: number;

  @ManyToOne(() => BacSi, (b) => b.khung_gio, { eager: true }) @JoinColumn({ name: 'bac_si_id' }) bac_si: BacSi;
  @OneToMany(() => LichHen, (l) => l.khung_gio) lich_hen: LichHen[];
}

export enum TrangThaiLich {
  CHO_XAC_NHAN = 'cho_xac_nhan',
  DA_XAC_NHAN = 'da_xac_nhan',
  DA_CHECKIN = 'da_checkin',
  DA_KHAM = 'da_kham',
  DA_HUY = 'da_huy',
}

@Entity('lich_hen')
export class LichHen {
  @PrimaryGeneratedColumn() id: number;
  @Column({ unique: true }) ma_lich_hen: string;
  @Column({ type: 'simple-enum', enum: TrangThaiLich, default: TrangThaiLich.CHO_XAC_NHAN }) trang_thai: TrangThaiLich;
  @Column({ type: 'int', nullable: true }) so_thu_tu: number;
  @CreateDateColumn() ngay_tao: Date;

  @ManyToOne(() => HoSoBenhNhan, (h) => h.lich_hen, { eager: true }) @JoinColumn({ name: 'ho_so_id' }) ho_so: HoSoBenhNhan;
  @ManyToOne(() => KhungGio, { eager: true }) @JoinColumn({ name: 'khung_gio_id' }) khung_gio: KhungGio;
  @ManyToOne(() => KhoaPhong, { eager: true }) @JoinColumn({ name: 'khoa_id' }) khoa: KhoaPhong;
  @OneToOne('LuotKham', 'lich_hen') luot_kham: any;
}

export enum TrangThaiKham {
  DANG_KHAM = 'dang_kham',
  HOAN_THANH = 'hoan_thanh',
}

@Entity('luot_kham')
export class LuotKham {
  @PrimaryGeneratedColumn() id: number;
  @Column({ type: 'text', nullable: true }) chan_doan: string;
  @Column({ type: 'text', nullable: true }) chi_dinh: string;
  @Column({ type: 'text', nullable: true }) ghi_chu: string;
  @Column({ type: 'simple-enum', enum: TrangThaiKham, default: TrangThaiKham.DANG_KHAM }) trang_thai: TrangThaiKham;
  @CreateDateColumn() thoi_gian: Date;

  @OneToOne(() => LichHen, (l) => l.luot_kham) @JoinColumn({ name: 'lich_hen_id' }) lich_hen: LichHen;
  @ManyToOne(() => BacSi, { eager: true }) @JoinColumn({ name: 'bac_si_id' }) bac_si: BacSi;
  @OneToOne('DonThuoc', 'luot_kham') don_thuoc: any;
}

@Entity('don_thuoc')
export class DonThuoc {
  @PrimaryGeneratedColumn() id: number;
  @Column({ type: 'text', nullable: true }) danh_sach_thuoc: string;
  @Column({ type: 'text', nullable: true }) lieu_dung: string;
  @Column({ type: 'text', nullable: true }) ghi_chu: string;
  @OneToOne(() => LuotKham, (v) => v.don_thuoc) @JoinColumn({ name: 'luot_kham_id' }) luot_kham: LuotKham;
}

@Entity('tin_tuc')
export class TinTuc {
  @PrimaryGeneratedColumn() id: number;
  @Column() tieu_de: string;
  @Column({ nullable: true }) tag: string;
  @Column({ type: 'text', nullable: true }) noi_dung: string;
  @Column({ nullable: true }) anh: string;
  @CreateDateColumn() ngay_dang: Date;
}
