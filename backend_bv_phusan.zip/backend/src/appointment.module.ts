import {
  Injectable, Controller, Get, Post, Patch, Body, Param, Request, UseGuards,
  BadRequestException, NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import {
  LichHen, KhungGio, HoSoBenhNhan, LuotKham, DonThuoc, TrangThaiLich, TrangThaiKham, VaiTro,
} from './entities';
import { JwtAuthGuard, RolesGuard, Roles } from './auth';

@Injectable()
export class ApptService {
  constructor(
    @InjectRepository(LichHen) private lich: Repository<LichHen>,
    @InjectRepository(KhungGio) private slot: Repository<KhungGio>,
    @InjectRepository(HoSoBenhNhan) private hoSo: Repository<HoSoBenhNhan>,
    @InjectRepository(LuotKham) private luot: Repository<LuotKham>,
    @InjectRepository(DonThuoc) private don: Repository<DonThuoc>,
    private ds: DataSource,
  ) {}

  // ----- Đặt lịch (giao dịch để tránh đặt trùng quá slot) -----
  async datLich(userId: number, dto: any) {
    return this.ds.transaction(async (m) => {
      const slot = await m.findOne(KhungGio, { where: { id: dto.khung_gio_id }, relations: ['bac_si', 'bac_si.khoa'] });
      if (!slot) throw new NotFoundException('Khung giờ không tồn tại');
      if (slot.da_dat >= slot.so_luong) throw new BadRequestException('Khung giờ đã hết chỗ');

      let hoSo = await m.findOne(HoSoBenhNhan, { where: { id: dto.ho_so_id } });
      if (!hoSo) {
        // tự tạo hồ sơ nhanh từ thông tin gửi lên
        hoSo = await m.save(m.create(HoSoBenhNhan, {
          ma_benh_nhan: 'BN' + Date.now().toString().slice(-8),
          ho_ten: dto.ho_ten, sdt: dto.sdt, so_bhyt: dto.so_bhyt,
          nguoi_dung: { id: userId } as any,
        }));
      }

      slot.da_dat += 1;
      await m.save(slot);

      const ma = 'BV' + Math.random().toString(36).slice(2, 7).toUpperCase();
      const lich = await m.save(m.create(LichHen, {
        ma_lich_hen: ma, ho_so: hoSo, khung_gio: slot, khoa: slot.bac_si.khoa,
        trang_thai: TrangThaiLich.CHO_XAC_NHAN, so_thu_tu: slot.da_dat,
      }));
      return { ma_lich_hen: ma, so_thu_tu: lich.so_thu_tu, trang_thai: lich.trang_thai, id: lich.id };
    });
  }

  async lichCuaToi(userId: number) {
    return this.lich.find({
      where: { ho_so: { nguoi_dung: { id: userId } } },
      order: { ngay_tao: 'DESC' },
    });
  }

  async huyLich(userId: number, id: number) {
    const lich = await this.lich.findOne({ where: { id }, relations: ['khung_gio', 'ho_so', 'ho_so.nguoi_dung'] });
    if (!lich) throw new NotFoundException('Không tìm thấy lịch hẹn');
    if (lich.ho_so.nguoi_dung?.id !== userId) throw new BadRequestException('Không thể hủy lịch của người khác');
    lich.trang_thai = TrangThaiLich.DA_HUY;
    await this.lich.save(lich);
    const slot = lich.khung_gio;
    if (slot.da_dat > 0) { slot.da_dat -= 1; await this.slot.save(slot); }
    return { message: 'Đã hủy lịch hẹn', ma_lich_hen: lich.ma_lich_hen };
  }

  // ----- Tiếp đón: tra cứu + check-in -----
  traCuu(ma: string) {
    return this.lich.findOne({ where: { ma_lich_hen: ma } });
  }
  async checkin(id: number) {
    const lich = await this.lich.findOneBy({ id });
    if (!lich) throw new NotFoundException('Không tìm thấy lịch hẹn');
    lich.trang_thai = TrangThaiLich.DA_CHECKIN;
    return this.lich.save(lich);
  }

  // ----- Bác sĩ: hàng chờ + ghi kết quả -----
  hangCho() {
    return this.lich.find({
      where: { trang_thai: TrangThaiLich.DA_CHECKIN },
      order: { so_thu_tu: 'ASC' },
    });
  }

  async ghiKetQua(lichId: number, bacSiId: number, dto: any) {
    const lich = await this.lich.findOneBy({ id: lichId });
    if (!lich) throw new NotFoundException('Không tìm thấy lịch hẹn');
    const luot = await this.luot.save(this.luot.create({
      lich_hen: lich, bac_si: { id: bacSiId } as any,
      chan_doan: dto.chan_doan, chi_dinh: dto.chi_dinh, ghi_chu: dto.ghi_chu,
      trang_thai: TrangThaiKham.HOAN_THANH,
    }));
    if (dto.don_thuoc) {
      await this.don.save(this.don.create({ luot_kham: luot, danh_sach_thuoc: dto.don_thuoc, lieu_dung: dto.lieu_dung }));
    }
    lich.trang_thai = TrangThaiLich.DA_KHAM;
    await this.lich.save(lich);
    return { message: 'Đã lưu kết quả khám', luot_kham_id: luot.id };
  }

  lichSuKham(hoSoId: number) {
    return this.luot.find({ where: { lich_hen: { ho_so: { id: hoSoId } } }, relations: ['lich_hen'], order: { thoi_gian: 'DESC' } });
  }

  // ----- Báo cáo (admin) -----
  async baoCao() {
    const tong = await this.lich.count();
    const daKham = await this.lich.count({ where: { trang_thai: TrangThaiLich.DA_KHAM } });
    const daHuy = await this.lich.count({ where: { trang_thai: TrangThaiLich.DA_HUY } });
    return {
      tong_luot_dat: tong,
      da_kham: daKham,
      da_huy: daHuy,
      ty_le_den_kham: tong ? Math.round((daKham / tong) * 100) : 0,
    };
  }
}

@Controller('api')
export class ApptController {
  constructor(private svc: ApptService) {}

  // Bệnh nhân
  @UseGuards(JwtAuthGuard) @Post('appointments') dat(@Request() r, @Body() b) { return this.svc.datLich(r.user.id, b); }
  @UseGuards(JwtAuthGuard) @Get('appointments/me') cuaToi(@Request() r) { return this.svc.lichCuaToi(r.user.id); }
  @UseGuards(JwtAuthGuard) @Patch('appointments/:id/cancel') huy(@Request() r, @Param('id') id) { return this.svc.huyLich(r.user.id, +id); }

  // Tiếp đón
  @UseGuards(JwtAuthGuard, RolesGuard) @Roles(VaiTro.LE_TAN, VaiTro.ADMIN)
  @Get('reception/lookup/:ma') traCuu(@Param('ma') ma) { return this.svc.traCuu(ma); }
  @UseGuards(JwtAuthGuard, RolesGuard) @Roles(VaiTro.LE_TAN, VaiTro.ADMIN)
  @Post('reception/checkin/:id') checkin(@Param('id') id) { return this.svc.checkin(+id); }

  // Bác sĩ
  @UseGuards(JwtAuthGuard, RolesGuard) @Roles(VaiTro.BAC_SI, VaiTro.ADMIN)
  @Get('queue') hangCho() { return this.svc.hangCho(); }
  @UseGuards(JwtAuthGuard, RolesGuard) @Roles(VaiTro.BAC_SI, VaiTro.ADMIN)
  @Post('visits/:id/result') ghi(@Request() r, @Param('id') id, @Body() b) { return this.svc.ghiKetQua(+id, b.bac_si_id || 1, b); }
  @UseGuards(JwtAuthGuard) @Get('records/:hoSoId') lichSu(@Param('hoSoId') id) { return this.svc.lichSuKham(+id); }

  // Admin
  @UseGuards(JwtAuthGuard, RolesGuard) @Roles(VaiTro.ADMIN)
  @Get('admin/reports') baoCao() { return this.svc.baoCao(); }
}
